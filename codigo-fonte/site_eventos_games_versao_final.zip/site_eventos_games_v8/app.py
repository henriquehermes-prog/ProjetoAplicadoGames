from datetime import datetime
from pathlib import Path
import re
import sqlite3

from flask import Flask, flash, redirect, render_template, request, url_for, session
from functools import wraps

app = Flask(__name__)
app.secret_key = 'secret'
app.config['SESSION_PERMANENT'] = False  # Faz a sessão expirar ao fechar o navegador

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / 'eventos_games.db'
EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')


def conectar():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def criar_tabelas():
    conn = conectar()

    conn.execute("""
    CREATE TABLE IF NOT EXISTS Usuario(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT,
        email TEXT UNIQUE,
        senha TEXT,
        apelido TEXT,
        foto TEXT,
        bio TEXT,
        data_nascimento TEXT,
        status TEXT,
        criado_em TEXT
    )
    """)

    conn.execute("""
    CREATE TABLE IF NOT EXISTS Equipe(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT,
        max_integrantes INTEGER
    )
    """)

    conn.execute("""
    CREATE TABLE IF NOT EXISTS EquipeUsuario(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        equipe_id INTEGER,
        usuario_id INTEGER
    )
    """)

    conn.execute("""
    CREATE TABLE IF NOT EXISTS Evento(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT,
        descricao TEXT,
        data TEXT,
        limite_participantes INTEGER,
        tipo_participacao TEXT,
        formato TEXT,
        publico TEXT,
        codigo_acesso TEXT,
        status TEXT,
        organizador_id INTEGER,
        jogo_id INTEGER
    )
    """)

    conn.execute("""
    CREATE TABLE IF NOT EXISTS Inscricao(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        evento_id INTEGER,
        equipe_id INTEGER
    )
    """)

    conn.execute("""
    CREATE TABLE IF NOT EXISTS Partida(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        evento_id INTEGER,
        equipe1 TEXT,
        equipe2 TEXT,
        placar TEXT,
        fase TEXT
    )
    """)

    conn.execute("""
    CREATE TABLE IF NOT EXISTS Ranking(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        evento_id INTEGER,
        equipe TEXT,
        pontos INTEGER
    )
    """)
    # Forçar a criação da coluna 'fase' caso a tabela já exista de versões anteriores
    try:
        conn.execute("ALTER TABLE Partida ADD COLUMN fase TEXT DEFAULT 'Geral'")
        conn.commit()
    except sqlite3.OperationalError:
        # Se a coluna já existir, ele vai dar erro e cair aqui, ignorando com segurança
        pass

    conn.commit()
    conn.close()


def normalizar_texto(valor):
    return (valor or '').strip()


def flash_erros(erros):
    for erro in erros:
        flash(erro, 'danger')


def contar(conn, tabela):
    return conn.execute(f'SELECT COUNT(*) total FROM {tabela}').fetchone()['total']


def evento_stats(conn, evento_id, limite=None):
    inscritos = conn.execute(
        'SELECT COUNT(*) total FROM Inscricao WHERE evento_id=?',
        (evento_id,)
    ).fetchone()['total']

    vagas = None
    if limite is not None:
        try:
            limite_int = int(limite)
        except (TypeError, ValueError):
            limite_int = 0
        vagas = max(limite_int - inscritos, 0)

    return {
        'inscritos': inscritos,
        'vagas': vagas,
        'lotado': vagas == 0 if vagas is not None else False
    }


def requer_perfil(*perfis):
    perfil = session.get('perfil')

    if perfil == 'admin':
        return True

    if perfil not in perfis:
        flash('Acesso negado.', 'danger')
        return False

    return True

def login_obrigatorio(f):
    @wraps(f)
    def decorated(*args, **kwargs):

        if 'usuario' not in session:
            flash('Faça login para continuar.', 'warning')
            return redirect(url_for('login'))

        return f(*args, **kwargs)

    return decorated

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        usuario = request.form.get('usuario')
        senha = request.form.get('senha')
        
        # Validação exata das contas de teste
        if usuario == 'jogador' and senha == 'jogador123':
            session.clear() # Limpa resíduos de sessões antigas
            session['usuario'] = 'jogador'
            session['perfil'] = 'jogador'
            flash('Conectado com sucesso como Jogador!', 'success')
            return redirect('/') # Redireciona para a página inicial
            
        elif usuario == 'organizador' and senha == 'org123':
            session.clear()
            session['usuario'] = 'organizador'
            session['perfil'] = 'organizador'
            flash('Conectado com sucesso como Organizador!', 'success')
            return redirect('/')
            
        elif usuario == 'admin' and senha == 'admin123':
            session.clear()
            session['usuario'] = 'admin'
            session['perfil'] = 'admin'
            flash('Conectado com sucesso como Administrador!', 'success')
            return redirect('/')

        else:
            flash('Usuário ou senha incorretos.', 'danger')
            
    return render_template('login.html')

@app.before_request
def verificar_login_obrigatorio():

    rotas_publicas = [
        'home',
        'eventos',
        'evento',
        'equipes',
        'usuarios',
        'login',
        'cadastro',
        'static'
    ]

    if request.endpoint in rotas_publicas:
        return

    if 'usuario' not in session:
        flash('Faça login para continuar.', 'warning')
        return redirect(url_for('login'))

@app.route('/')
def home():
    
    conn = conectar()

    busca = normalizar_texto(request.args.get('busca'))
    formato = normalizar_texto(request.args.get('formato'))
    publico = normalizar_texto(request.args.get('publico'))

    filtros = ["status='Ativo'"]
    params = []

    if busca:
        filtros.append('(nome LIKE ? OR descricao LIKE ? OR jogo_id LIKE ?)')
        termo = f'%{busca}%'
        params.extend([termo, termo, termo])

    if formato:
        filtros.append('formato=?')
        params.append(formato)

    if publico:
        filtros.append('publico=?')
        params.append(publico)

    eventos = conn.execute(f"""
    SELECT * FROM Evento
    WHERE {' AND '.join(filtros)}
    ORDER BY data ASC, id DESC
    """, params).fetchall()

    stats = {
        evento['id']: evento_stats(conn, evento['id'], evento['limite_participantes'])
        for evento in eventos
    }

    resumo = {
        'eventos': len(eventos),
        'usuarios': contar(conn, 'Usuario'),
        'equipes': contar(conn, 'Equipe')
    }

    conn.close()

    return render_template(
        'home.html',
        eventos=eventos,
        stats=stats,
        resumo=resumo,
        filtros={'busca': busca, 'formato': formato, 'publico': publico}
    )


@app.route('/usuarios', methods=['GET', 'POST'])
def usuarios():

    if request.method == 'POST':
        if 'usuario' not in session:
            flash('Faça login para cadastrar jogadores.', 'warning')
            return redirect(url_for('login'))
        if not requer_perfil('jogador', 'admin'):
            return redirect(url_for('usuarios'))

    conn = conectar()

    if request.method == 'POST':
        nome = normalizar_texto(request.form.get('nome'))
        email = normalizar_texto(request.form.get('email')).lower()
        senha = request.form.get('senha', '')
        confirmar_senha = request.form.get('confirmar_senha', '')
        apelido = normalizar_texto(request.form.get('apelido'))
        foto = normalizar_texto(request.form.get('foto'))
        bio = normalizar_texto(request.form.get('bio'))
        status = normalizar_texto(request.form.get('status')) or 'Ativo'
        data_nascimento = request.form.get('data_nascimento')

        erros = []
        if not nome:
            erros.append('Informe o nome completo do jogador.')
        if not data_nascimento:
            erros.append('Informe a data de nascimento.')
        if not EMAIL_RE.match(email):
            erros.append('Informe um e-mail válido.')
        if len(senha) < 8:
            erros.append('A senha deve ter pelo menos 8 caracteres.')
        if senha != confirmar_senha:
            erros.append('A confirmação de senha não confere.')

        if erros:
            flash_erros(erros)
        else:
            try:
                conn.execute("""
                INSERT INTO Usuario(
                    nome,email,senha,apelido,foto,bio,data_nascimento,status,criado_em
                )
                VALUES(?,?,?,?,?,?,?,?,?)
                """, (
                    nome,
                    email,
                    senha,
                    apelido,
                    foto,
                    bio,
                    data_nascimento,
                    status,
                    datetime.now().strftime('%d/%m/%Y %H:%M')
                ))
                conn.commit()
                flash('Usuário cadastrado com sucesso!', 'success')
                conn.close()
                return redirect(url_for('usuarios'))
            except sqlite3.IntegrityError:
                flash('Já existe um jogador cadastrado com este e-mail.', 'danger')

    usuarios_lista = conn.execute('SELECT * FROM Usuario ORDER BY nome').fetchall()
    conn.close()

    return render_template('usuarios.html', usuarios=usuarios_lista)


@app.route('/usuario/editar/<int:id>', methods=['GET', 'POST'])
@login_obrigatorio
def editar_usuario(id):

    if not requer_perfil('jogador', 'admin'):
        return redirect('/')

    conn = conectar()

    usuario = conn.execute(
        'SELECT * FROM Usuario WHERE id=?',
        (id,)
    ).fetchone()

    if not usuario:
        conn.close()
        flash('Usuário não encontrado.', 'danger')
        return redirect('/usuarios')

    if request.method == 'POST':
        nome = normalizar_texto(request.form.get('nome'))
        email = normalizar_texto(request.form.get('email')).lower()
        nova_senha = request.form.get('senha', '')
        senha_atual = request.form.get('senha_atual', '')
        senha_atual = request.form.get('senha_atual', '')
        data_nascimento = request.form.get('data_nascimento')

        erros = []
        if senha_atual != usuario['senha']:
            erros.append('Senha atual incorreta.')
        if not nome:
            erros.append('Informe o nome completo do jogador.')
        if not data_nascimento:
            erros.append('Informe a data de nascimento.')
        if not EMAIL_RE.match(email):
            erros.append('Informe um e-mail válido.')
        if nova_senha and len(nova_senha) < 8:
            erros.append('A nova senha deve ter pelo menos 8 caracteres.')
        if senha_atual != usuario['senha']:
            erros.append('Senha atual incorreta.')

        if erros:
            flash_erros(erros)
        else:
            try:
                conn.execute("""
                UPDATE Usuario SET
                nome=?,
                email=?,
                senha=?,
                apelido=?,
                foto=?,
                bio=?,
                data_nascimento=?,
                status=?
                WHERE id=?
                """, (
                    nome,
                    email,
                    nova_senha if nova_senha else usuario['senha'],
                    normalizar_texto(request.form.get('apelido')),
                    normalizar_texto(request.form.get('foto')),
                    normalizar_texto(request.form.get('bio')),
                    data_nascimento,
                    normalizar_texto(request.form.get('status')),
                    id
                ))
                conn.commit()
                conn.close()
                flash('Usuário atualizado com sucesso!', 'success')
                return redirect('/usuarios')
            except sqlite3.IntegrityError:
                flash('Já existe outro usuário com este e-mail.', 'danger')

    conn.close()
    return render_template('editar_usuario.html', usuario=usuario)

@app.route('/equipes', methods=['GET', 'POST'])
def equipes():

    if request.method == 'POST':

        if 'usuario' not in session:
            flash('Faça login para criar uma equipe.', 'warning')
            return redirect(url_for('login'))

        if not requer_perfil('jogador', 'admin'):
            return redirect(url_for('equipes'))

    conn = conectar()

    if request.method == 'POST':
        nome = normalizar_texto(request.form.get('nome'))
        try:
            max_integrantes = int(request.form.get('max_integrantes', 0))
        except ValueError:
            max_integrantes = 0

        if not nome or max_integrantes < 1:
            flash('Informe o nome da equipe e um limite válido de integrantes.', 'danger')
        else:
            conn.execute("""
            INSERT INTO Equipe(nome,max_integrantes)
            VALUES(?,?)
            """, (nome, max_integrantes))
            conn.commit()
            flash('Equipe cadastrada com sucesso!', 'success')

    equipes_lista = conn.execute('SELECT * FROM Equipe ORDER BY nome').fetchall()
    usuarios_lista = conn.execute(
        "SELECT * FROM Usuario WHERE status='Ativo' ORDER BY nome"
    ).fetchall()

    integrantes = conn.execute("""
    SELECT
        eu.id,
        e.id equipe_id,
        e.nome equipe,
        u.nome usuario
    FROM EquipeUsuario eu
    JOIN Equipe e ON e.id = eu.equipe_id
    JOIN Usuario u ON u.id = eu.usuario_id
    ORDER BY e.nome, u.nome
    """).fetchall()

    ocupacao = {}
    for equipe in equipes_lista:
        ocupacao[equipe['id']] = conn.execute(
            'SELECT COUNT(*) total FROM EquipeUsuario WHERE equipe_id=?',
            (equipe['id'],)
        ).fetchone()['total']

    conn.close()

    return render_template(
        'equipes.html',
        equipes=equipes_lista,
        usuarios=usuarios_lista,
        integrantes=integrantes,
        ocupacao=ocupacao
    )


@app.route('/equipe/adicionar', methods=['POST'])
@login_obrigatorio
def adicionar_integrante():
    if not requer_perfil('jogador', 'admin'): return redirect('/login')
    conn = conectar()

    equipe_id = request.form.get('equipe_id')
    usuario_id = request.form.get('usuario_id')

    equipe = conn.execute(
        'SELECT * FROM Equipe WHERE id=?',
        (equipe_id,)
    ).fetchone()

    if not equipe:
        flash('Equipe não encontrada.', 'danger')
        conn.close()
        return redirect('/equipes')

    quantidade = conn.execute(
        'SELECT COUNT(*) total FROM EquipeUsuario WHERE equipe_id=?',
        (equipe_id,)
    ).fetchone()['total']

    if quantidade >= equipe['max_integrantes']:
        flash('Limite máximo de integrantes atingido.', 'warning')
        conn.close()
        return redirect('/equipes')

    existente = conn.execute("""
    SELECT * FROM EquipeUsuario
    WHERE equipe_id=? AND usuario_id=?
    """, (equipe_id, usuario_id)).fetchone()

    if existente:
        flash('Usuário já está na equipe.', 'warning')
        conn.close()
        return redirect('/equipes')

    conn.execute("""
    INSERT INTO EquipeUsuario(equipe_id,usuario_id)
    VALUES(?,?)
    """, (equipe_id, usuario_id))

    conn.commit()
    conn.close()

    flash('Integrante adicionado!', 'success')
    return redirect('/equipes')


@app.route('/equipe/remover/<int:id>')
@login_obrigatorio
def remover_integrante(id):
    if not requer_perfil('jogador', 'admin'): return redirect('/login')
    conn = conectar()

    conn.execute(
        'DELETE FROM EquipeUsuario WHERE id=?',
        (id,)
    )

    conn.commit()
    conn.close()

    flash('Integrante removido!', 'success')
    return redirect('/equipes')


@app.route('/eventos', methods=['GET', 'POST'])
def eventos():

    if request.method == 'POST':
        if 'usuario' not in session:
            flash('Faça login para criar um torneio.', 'warning')
            return redirect(url_for('login'))

        if not requer_perfil('organizador', 'admin'):
            return redirect('/')

    conn = conectar()

    usuarios_lista = conn.execute(
        "SELECT * FROM Usuario WHERE status='Ativo' ORDER BY nome"
    ).fetchall()

    if request.method == 'POST':
        nome = normalizar_texto(request.form.get('nome'))
        descricao = normalizar_texto(request.form.get('descricao'))
        data = normalizar_texto(request.form.get('data'))
        publico = normalizar_texto(request.form.get('publico'))
        codigo_acesso = normalizar_texto(request.form.get('codigo_acesso'))

        try:
            limite = int(request.form.get('limite_participantes', 0))
        except ValueError:
            limite = 0

        erros = []
        if not nome:
            erros.append('Informe o nome do evento.')
        if not descricao:
            erros.append('Informe uma descrição para orientar os participantes.')
        if not data:
            erros.append('Informe data e horário do evento.')
        if limite < 1:
            erros.append('O limite de participantes deve ser maior que zero.')
        if publico == 'Privado' and not codigo_acesso:
            erros.append('Eventos privados precisam de código de acesso.')
        if not request.form.get('organizador_id'):
            erros.append('Cadastre ou selecione um organizador ativo.')

        if erros:
            flash_erros(erros)
        else:
            conn.execute("""
            INSERT INTO Evento(
                nome,descricao,data,limite_participantes,
                tipo_participacao,formato,publico,
                codigo_acesso,status,organizador_id,jogo_id
            )
            VALUES(?,?,?,?,?,?,?,?,?,?,?)
            """, (
                nome,
                descricao,
                data,
                limite,
                normalizar_texto(request.form.get('tipo_participacao')),
                normalizar_texto(request.form.get('formato')),
                publico,
                codigo_acesso,
                normalizar_texto(request.form.get('status')),
                request.form.get('organizador_id'),
                normalizar_texto(request.form.get('jogo_id'))
            ))
            conn.commit()
            flash('Evento cadastrado com sucesso!', 'success')
            conn.close()
            return redirect('/eventos')

    eventos_lista = conn.execute("""
    SELECT ev.*, u.nome organizador
    FROM Evento ev
    LEFT JOIN Usuario u ON u.id = ev.organizador_id
    ORDER BY ev.data ASC, ev.id DESC
    """).fetchall()

    stats = {
        evento['id']: evento_stats(conn, evento['id'], evento['limite_participantes'])
        for evento in eventos_lista
    }

    conn.close()

    return render_template(
        'eventos.html',
        eventos=eventos_lista,
        usuarios=usuarios_lista,
        stats=stats
    )


@app.route('/evento/<int:id>')
def evento(id):
    conn = conectar()

    evento_item = conn.execute("""
    SELECT ev.*, u.nome organizador
    FROM Evento ev
    LEFT JOIN Usuario u ON u.id = ev.organizador_id
    WHERE ev.id=?
    """, (id,)).fetchone()

    if not evento_item:
        conn.close()
        flash('Evento não encontrado.', 'danger')
        return redirect('/')

    equipes_lista = conn.execute('SELECT * FROM Equipe ORDER BY nome').fetchall()

    inscricoes = conn.execute("""
    SELECT i.id, e.id equipe_id, e.nome
    FROM Inscricao i
    JOIN Equipe e ON e.id=i.equipe_id
    WHERE i.evento_id=?
    ORDER BY e.nome
    """, (id,)).fetchall()

    partidas = conn.execute(
        'SELECT * FROM Partida WHERE evento_id=? ORDER BY id DESC',
        (id,)
    ).fetchall()

    ranking_lista = conn.execute(
        'SELECT * FROM Ranking WHERE evento_id=? ORDER BY pontos DESC',
        (id,)
    ).fetchall()

    stats = evento_stats(conn, id, evento_item['limite_participantes'])
    inscritos_ids = {item['equipe_id'] for item in inscricoes}
    equipes_disponiveis = [
        equipe for equipe in equipes_lista if equipe['id'] not in inscritos_ids
    ]

    conn.close()

    return render_template(
        'evento.html',
        evento=evento_item,
        equipes=equipes_disponiveis,
        inscricoes=inscricoes,
        partidas=partidas,
        ranking=ranking_lista,
        stats=stats
    )


@app.route('/evento/<int:id>/inscrever', methods=['POST'])
@login_obrigatorio
def inscrever(id):

    if not requer_perfil('jogador', 'admin'):
        return redirect(url_for('evento', id=id))

    conn = conectar()

    evento_item = conn.execute(
        'SELECT * FROM Evento WHERE id=?',
        (id,)
    ).fetchone()

    if not evento_item:
        flash('Evento não encontrado.', 'danger')
        conn.close()
        return redirect('/')

    stats = evento_stats(conn, id, evento_item['limite_participantes'])
    equipe_id = request.form.get('equipe_id')
    codigo = normalizar_texto(request.form.get('codigo_acesso'))

    if stats['lotado']:
        flash('As inscrições deste evento já atingiram o limite.', 'warning')
        conn.close()
        return redirect(f'/evento/{id}')

    if not equipe_id:
        flash('Selecione uma equipe para fazer a inscrição.', 'danger')
        conn.close()
        return redirect(f'/evento/{id}')

    if evento_item['publico'] == 'Privado' and codigo != (evento_item['codigo_acesso'] or ''):
        flash('Código de acesso inválido para este evento privado.', 'danger')
        conn.close()
        return redirect(f'/evento/{id}')

    existente = conn.execute("""
    SELECT * FROM Inscricao
    WHERE evento_id=? AND equipe_id=?
    """, (id, equipe_id)).fetchone()

    if existente:
        flash('Esta equipe já está inscrita no evento.', 'warning')
        conn.close()
        return redirect(f'/evento/{id}')

    conn.execute("""
    INSERT INTO Inscricao(evento_id,equipe_id)
    VALUES(?,?)
    """, (id, equipe_id))

    conn.commit()
    conn.close()

    flash('Equipe inscrita com sucesso!', 'success')
    return redirect(f'/evento/{id}')


@app.route('/evento/<int:id>/partida', methods=['POST'])
@login_obrigatorio
def partida(id):
    if not requer_perfil('organizador', 'admin'):
        return redirect(url_for('evento', id=id))
    
    conn = conectar()

    equipe1 = normalizar_texto(request.form.get('equipe1'))
    equipe2 = normalizar_texto(request.form.get('equipe2'))
    placar = normalizar_texto(request.form.get('placar'))
    fase = normalizar_texto(request.form.get('fase')) or 'Geral' # Coleta o valor do novo input

    equipes_inscritas = conn.execute("""
        SELECT e.nome
        FROM Inscricao i
        JOIN Equipe e ON e.id = i.equipe_id
        WHERE i.evento_id = ?
    """, (id,)).fetchall()

    nomes_equipes = [equipe['nome'] for equipe in equipes_inscritas]

    if not equipe1 or not equipe2:
        flash('Informe as duas equipes da partida.', 'danger')
    elif equipe1 == equipe2:
        flash('A partida precisa ter equipes diferentes.', 'danger')
    elif equipe1 not in nomes_equipes:
        flash(f'A equipe "{equipe1}" não está inscrita neste torneio.', 'danger')
    elif equipe2 not in nomes_equipes:
        flash(f'A equipe "{equipe2}" não está inscrita neste torneio.', 'danger')
    else:
        # Inclui o campo 'fase' na query SQL
        conn.execute("""
        INSERT INTO Partida(evento_id,equipe1,equipe2,placar,fase)
        VALUES(?,?,?,?,?)
        """, (id, equipe1, equipe2, placar or 'A definir', fase))

        conn.commit()
        flash('Partida salva com sucesso!', 'success')

    conn.close()
    return redirect(f'/evento/{id}')


@app.route('/evento/<int:id>/ranking', methods=['POST'])
@login_obrigatorio
def ranking(id):
    if not requer_perfil('organizador', 'admin'):
        return redirect(url_for('evento', id=id))
    
    conn = conectar()

    equipe = normalizar_texto(request.form.get('equipe'))
    try:
        pontos = int(request.form.get('pontos', 0))
    except ValueError:
        pontos = 0

    if not equipe:
        flash('Informe a equipe para atualizar o ranking.', 'danger')
    else:
        existente = conn.execute("""
        SELECT * FROM Ranking
        WHERE evento_id=? AND equipe=?
        """, (id, equipe)).fetchone()

        if existente:
            conn.execute("""
            UPDATE Ranking SET pontos=?
            WHERE id=?
            """, (pontos, existente['id']))
        else:
            conn.execute("""
            INSERT INTO Ranking(evento_id,equipe,pontos)
            VALUES(?,?,?)
            """, (id, equipe, pontos))

        conn.commit()
        flash('Ranking atualizado!', 'success')

    conn.close()
    return redirect(f'/evento/{id}')



@app.route('/equipe/editar/<int:id>', methods=['GET','POST'])
@login_obrigatorio
def editar_equipe(id):

    if not requer_perfil('jogador', 'admin'):
        return redirect('/equipes')

    conn=conectar()
    equipe=conn.execute('SELECT * FROM Equipe WHERE id=?',(id,)).fetchone()
    if request.method=='POST' and equipe:
        nome=normalizar_texto(request.form.get('nome'))
        max_i=int(request.form.get('max_integrantes',1))
        conn.execute('UPDATE Equipe SET nome=?, max_integrantes=? WHERE id=?',(nome,max_i,id))
        conn.commit()
        flash('Equipe atualizada!','success')
        return redirect('/equipes')
    return render_template('editar_equipe.html', equipe=equipe)

@app.route('/equipe/excluir/<int:id>')
@login_obrigatorio
def excluir_equipe(id):

    if not requer_perfil('jogador', 'admin'):
        return redirect('/equipes')

    conn=conectar()
    existe=conn.execute('SELECT 1 FROM Inscricao WHERE equipe_id=?',(id,)).fetchone()
    if existe: flash('Equipe inscrita em torneio não pode ser excluída.','danger')
    else:
      conn.execute('DELETE FROM EquipeUsuario WHERE equipe_id=?',(id,))
      conn.execute('DELETE FROM Equipe WHERE id=?',(id,))
      conn.commit()
    return redirect('/equipes')

@app.route('/logout')
def logout():
    session.clear()  # Limpa completamente os dados da sessão
    flash('Você saiu da Arena com sucesso.', 'info')
    return redirect(url_for('home'))

if __name__ == '__main__':
    criar_tabelas()
    app.run(debug=True)

@app.route('/cadastro')
def cadastro():
    return 'Página de cadastro em construção'


@app.route('/perfil')
def perfil():
    return 'Página de perfil em construção'